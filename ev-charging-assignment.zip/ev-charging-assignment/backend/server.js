
// server.js and backend structure (summarized)
// You can paste the full content from the "Node Express Assignment" tab in your project
