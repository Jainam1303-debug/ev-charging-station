# EV Charging Station App
This is the complete solution for the full-stack assignment including backend (Node.js + Express + MongoDB), frontend (Vue.js), authentication, and deployment instructions.
Replace URLs with your deployed backend/frontend.
